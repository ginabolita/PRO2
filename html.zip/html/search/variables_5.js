var searchData=
[
  ['ubi_108',['ubi',['../classBicicleta.html#abb720dbe6e84b92774674842ae0c4e96',1,'Bicicleta']]]
];

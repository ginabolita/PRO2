var searchData=
[
  ['espacio_5flibre_103',['espacio_libre',['../classCjt__estaciones.html#a0d17109044c8e95610ebf6ba37a635f9',1,'Cjt_estaciones']]],
  ['estaciones_104',['estaciones',['../classCjt__estaciones.html#a8652454b2f630ceacd64dd22bd38274f',1,'Cjt_estaciones']]]
];
